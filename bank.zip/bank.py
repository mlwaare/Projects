import discord

from discord.ext import commands

import os

import json

# --- الإعدادات الرئيسية ---

TOKEN = "MTQxMzEwNDUxODcxNTE0NjM0NA.GdpWK7.Fl02GekkNFiq8qLVtmY4-s8r94B12_L_KprxMo" 

OWNER_IDS = {

    1396869479421444107, 

    525145153633893928, 

    9202082737378292

}

intents = discord.Intents.all()

bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)

# --- حدث الاستعداد وتحميل الـ Cogs ---

@bot.event

async def on_ready():

    print(f'Bot is ready and logged in as {bot.user}')

    

    folder_name = 'banks' # اسم المجلد الجديد

    if not os.path.exists(f'./{folder_name}'):

        os.makedirs(f'./{folder_name}')

        print(f"Created '{folder_name}' directory.")

    if not os.path.exists('data.json'):

        initial_data = {

            "global": {

                "king_id": None,

                "jobs": {

                    "شرطي": [], "عامل توصيل": [], "مدير اعمال": [],

                    "قاضي": [], "معلم": [], "طيار": [],

                    "طباخ": [], "مهندس": [], "دكتور": []

                },

                "gold_stock": 15,

                "gold_last_restock": 0

            }

        }

        with open('data.json', 'w') as f:

            json.dump(initial_data, f, indent=4)

    

    for filename in os.listdir(f'./{folder_name}'):

        if filename.endswith('.py'):

            try:

                await bot.load_extension(f'{folder_name}.{filename[:-3]}')

                print(f'Loaded Cog: {filename}')

            except Exception as e:

                print(f'Failed to load cog {filename}: {e}')

if __name__ == "__main__":

    if TOKEN == "YOUR_BOT_TOKEN_HERE":

        print("!!! ERROR: Please replace 'YOUR_BOT_TOKEN_HERE' in main.py with your actual bot token.")

    else:

        bot.run(TOKEN)