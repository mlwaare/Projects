import discord

from discord.ext import commands

import json

def get_data():

    with open('data.json', 'r', encoding='utf-8') as f:

        return json.load(f)

def save_data(data):

    with open('data.json', 'w', encoding='utf-8') as f:

        json.dump(data, f, indent=4, ensure_ascii=False)

def get_user_data(user_id):

    data = get_data()

    user_id_str = str(user_id)

    if user_id_str not in data:

        data[user_id_str] = {

            "wallet": 500, "bank": 1000, "bitcoin": 0,

            "properties": [], 

            "certificates": {},

            "job": None,

            "assets": {

                "computers": 0, "bots": 0, "exploits": 0,

                "last_mine_time": 0, "last_bot_build_time": 0, "last_exploit_time": 0

            },

            "cooldowns": { "هد": 0, "بقش": 0, "راتب": 0, "gamble": 0 }

        }

        save_data(data)

    return data[user_id_str]

class EconomyCog(commands.Cog):

    def __init__(self, bot):

        self.bot = bot

    @commands.command(aliases=['محفظة', 'فلوس'])

    async def bal(self, ctx, member: discord.Member = None):

        member = member or ctx.author

        user_data = get_user_data(member.id)

        embed = discord.Embed(title=f"رصيد {member.display_name}", color=discord.Color.gold())

        embed.add_field(name="💸 المحفظة", value=f"${user_data['wallet']:,}", inline=True)

        embed.add_field(name="🏦 البنك", value=f"${user_data['bank']:,}", inline=True)

        embed.add_field(name="🪙 البيتكوين", value=f"{user_data['bitcoin']}", inline=False)

        await ctx.send(embed=embed)

    # ... باقي أوامر هذا الملف تعمل ببادئة وهي نفسها لم تتغير ...

    # (ad, wit, giv, give-b, tran-bit)

    @commands.command(aliases=['ايداع'])

    async def ad(self, ctx, amount: str):

        data = get_data()

        user_id = str(ctx.author.id)

        user_data = get_user_data(ctx.author.id)

        amount_to_deposit = user_data['wallet'] if amount.lower() in ['all', 'كل'] else int(amount)

        if amount_to_deposit <= 0: return await ctx.send("المبلغ يجب أن يكون موجبًا.")

        if user_data['wallet'] < amount_to_deposit: return await ctx.send("رصيدك في المحفظة غير كافٍ.")

        data[user_id]['wallet'] -= amount_to_deposit

        data[user_id]['bank'] += amount_to_deposit

        save_data(data)

        await ctx.send(f"✅ تم إيداع `${amount_to_deposit:,}` في حسابك البنكي.")

    @commands.command(aliases=['سحب'])

    async def wit(self, ctx, amount: str):

        data = get_data()

        user_id = str(ctx.author.id)

        user_data = get_user_data(ctx.author.id)

        amount_to_withdraw = user_data['bank'] if amount.lower() in ['all', 'كل'] else int(amount)

        if amount_to_withdraw <= 0: return await ctx.send("المبلغ يجب أن يكون موجبًا.")

        if user_data['bank'] < amount_to_withdraw: return await ctx.send("رصيدك في البنك غير كافٍ.")

        data[user_id]['bank'] -= amount_to_withdraw

        data[user_id]['wallet'] += amount_to_withdraw

        save_data(data)

        await ctx.send(f"✅ تم سحب `${amount_to_withdraw:,}` إلى محفظتك.")

    @commands.command(aliases=['حول'])

    async def giv(self, ctx, member: discord.Member, amount: int):

        sender_id, receiver_id = str(ctx.author.id), str(member.id)

        if sender_id == receiver_id: return await ctx.send("لا يمكنك تحويل المال لنفسك!")

        if amount <= 0: return await ctx.send("المبلغ يجب أن يكون موجبًا.")

        

        data = get_data()

        sender_data = get_user_data(ctx.author.id)

        if sender_data['wallet'] < amount: return await ctx.send("رصيدك غير كافٍ لإتمام التحويل.")

        get_user_data(member.id)

        data[sender_id]['wallet'] -= amount

        data[receiver_id]['wallet'] += amount

        save_data(data)

        await ctx.send(f"✅ تم تحويل `${amount:,}` إلى {member.mention}.")

    @commands.command(name='give-b')

    async def give_bit(self, ctx, member: discord.Member, amount: int):

        sender_id, receiver_id = str(ctx.author.id), str(member.id)

        if sender_id == receiver_id: return await ctx.send("لا يمكنك تحويل البيتكوين لنفسك!")

        if amount <= 0: return await ctx.send("المبلغ يجب أن يكون موجبًا.")

        data = get_data()

        sender_data = get_user_data(ctx.author.id)

        if sender_data['bitcoin'] < amount: return await ctx.send("ليس لديك بيتكوين كافٍ.")

            

        get_user_data(member.id)

        data[sender_id]['bitcoin'] -= amount

        data[receiver_id]['bitcoin'] += amount

        save_data(data)

        await ctx.send(f"✅ تم تحويل `{amount}` بيتكوين إلى {member.mention}.")

    @commands.command(name='tran-bit')

    async def transform_bitcoin(self, ctx, amount: int):

        user_id = str(ctx.author.id)

        if amount <= 0: return await ctx.send("المبلغ يجب أن يكون موجبًا.")

        

        data = get_data()

        user_data = get_user_data(ctx.author.id)

        if user_data['bitcoin'] < amount: return await ctx.send(f"ليس لديك `{amount}` بيتكوين.")

        

        money_earned = amount * 50

        data[user_id]['bitcoin'] -= amount

        data[user_id]['bank'] += money_earned

        save_data(data)

        await ctx.send(f"✅ تم تحويل `{amount}` بيتكوين إلى `${money_earned:,}` وإضافتها لبنكك.")

async def setup(bot):

    await bot.add_cog(EconomyCog(bot))