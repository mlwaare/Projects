import discord

from discord.ext import commands

from discord.ui import Select, View

import time

from .economy_cog import get_user_data, get_data, save_data

CERTIFICATES = {

    "عسكرية": {"price": 100000, "wait": 7200, "jobs": ["شرطي"]}, "طب": {"price": 200000, "wait": 14400, "jobs": ["دكتور"]},

    "عادية": {"price": 10000, "wait": 900, "jobs": ["عامل توصيل"]}, "اقتصاد": {"price": 150000, "wait": 9000, "jobs": ["مدير اعمال"]},

    "هندسة": {"price": 150000, "wait": 9000, "jobs": ["مهندس"]}, "طعام": {"price": 50000, "wait": 3600, "jobs": ["طباخ"]},

    "طيران": {"price": 100000, "wait": 7200, "jobs": ["طيار"]}, "آداب": {"price": 200000, "wait": 14400, "jobs": ["معلم", "قاضي"]}

}

JOBS = {

    "قاضي": {"salary": 50000, "limit": 1}, "مهندس": {"salary": 30000, "limit": 1}, "شرطي": {"salary": 20000, "limit": 2},

    "طباخ": {"salary": 10000, "limit": 2}, "دكتور": {"salary": 50000, "limit": 1}, "معلم": {"salary": 15000, "limit": 1},

    "طيار": {"salary": 20000, "limit": 1}, "مدير اعمال": {"salary": 30000, "limit": 1}, "ملك": {"salary": 100000, "limit": 1},

    "عامل توصيل": {"salary": 5000, "limit": 3}

}

class JobsCog(commands.Cog):

    def __init__(self, bot):

        self.bot = bot

    async def handle_certificates(self, message):

        ctx = await self.bot.get_context(message)

        options = [discord.SelectOption(label=f"شهادة كلية {name}", description=f"السعر: ${d['price']:,}") for name, d in CERTIFICATES.items()]

        select = Select(placeholder="اختر الشهادة التي تريد شراءها...", options=options)

        async def callback(interaction: discord.Interaction):

            await interaction.response.defer()

            if interaction.user != ctx.author: return await interaction.followup.send("أنت لست من بدأ هذا الأمر!", ephemeral=True)

            

            cert_name = select.values[0].split(" ")[2]

            cert_price = CERTIFICATES[cert_name]['price']

            data, user_id = get_data(), str(interaction.user.id)

            user_data = get_user_data(user_id)

            

            if cert_name in user_data['certificates']: return await interaction.followup.send("أنت تملك هذه الشهادة بالفعل.", ephemeral=True)

            if user_data['wallet'] < cert_price: return await interaction.followup.send("رصيدك في المحفظة غير كافٍ.", ephemeral=True)

            

            data[user_id]['wallet'] -= cert_price

            data[user_id]['certificates'][cert_name] = time.time()

            save_data(data)

            wait_hours = CERTIFICATES[cert_name]['wait'] / 3600

            await interaction.followup.send(f"✅ تم شراء شهادة كلية {cert_name}. ستكون جاهزة للاستخدام بعد {wait_hours:.1f} ساعة.")

        view = View(timeout=60).add_item(select)

        await ctx.send("اختر من قائمة الشهادات المتاحة:", view=view)

    async def handle_jobs(self, message):

        ctx = await self.bot.get_context(message)

        options = [discord.SelectOption(label=name, description=f"الراتب: ${d['salary']:,}") for name, d in JOBS.items() if name != "ملك"]

        select = Select(placeholder="اختر الوظيفة التي تريد التقديم عليها...", options=options)

        async def callback(interaction: discord.Interaction):

            await interaction.response.defer()

            if interaction.user != ctx.author: return await interaction.followup.send("أنت لست من بدأ هذا الأمر!", ephemeral=True)

            

            job_name = select.values[0]

            data, user_id = get_data(), str(interaction.user.id)

            user_data = get_user_data(user_id)

            if user_data.get('job'): return await interaction.followup.send("لديك وظيفة بالفعل. يجب أن تستقيل أولاً.", ephemeral=True)

            if len(data['global']['jobs'].get(job_name, [])) >= JOBS[job_name]['limit']:

                return await interaction.followup.send("هذه الوظيفة ممتلئة حاليًا.", ephemeral=True)

            has_cert = False

            for cert, details in CERTIFICATES.items():

                if job_name in details['jobs']:

                    if cert in user_data['certificates']:

                        purchase_time = user_data['certificates'][cert]

                        if time.time() - purchase_time >= details['wait']:

                            has_cert = True; break

            

            if not has_cert: return await interaction.followup.send("ليس لديك الشهادة المطلوبة أو لم يمر وقت الانتظار.", ephemeral=True)

            data[user_id]['job'] = job_name

            data['global']['jobs'][job_name].append(int(user_id))

            save_data(data)

            await interaction.followup.send(f"🎉 تهانينا! لقد تم توظيفك كـ '{job_name}'.")

        view = View(timeout=60).add_item(select)

        await ctx.send("اختر من قائمة الوظائف المتاحة:", view=view)

    # --- Prefixed Commands ---

    @commands.command()

    async def استقالة(self, ctx):

        data, user_id = get_data(), str(ctx.author.id)

        user_data = get_user_data(user_id)

        current_job = user_data.get('job')

        if not current_job: return await ctx.send("أنت لا تعمل حاليًا.")

        data[user_id]['job'] = None

        if current_job != "ملك" and int(user_id) in data['global']['jobs'][current_job]:

            data['global']['jobs'][current_job].remove(int(user_id))

        elif current_job == "ملك": data['global']['king_id'] = None

        save_data(data)

        await ctx.send(f"لقد استقلت من وظيفتك كـ '{current_job}'.")

        

    @commands.command()

    async def راتب(self, ctx):

        user_id = str(ctx.author.id)

        data = get_data()

        user_data = get_user_data(user_id)

        current_job = user_data.get('job')

        if not current_job: return await ctx.send("أنت لا تعمل حاليًا للحصول على راتب.")

        

        cooldowns = user_data['cooldowns']

        if time.time() - cooldowns.get('راتب', 0) < 43200:

            remaining_time = 43200 - (time.time() - cooldowns.get('راتب', 0))

            hours, minutes = int(remaining_time // 3600), int((remaining_time % 3600) // 60)

            return await ctx.send(f"يمكنك استلام راتبك مرة أخرى بعد {hours} ساعة و {minutes} دقيقة.")

        

        salary = JOBS[current_job]['salary']

        data[user_id]['bank'] += salary

        data[user_id]['cooldowns']['راتب'] = time.time()

        save_data(data)

        await ctx.send(f"✅ تم استلام راتبك لوظيفة '{current_job}'! أُضيف `${salary:,}` إلى بنكك.")

async def setup(bot):

    await bot.add_cog(JobsCog(bot))