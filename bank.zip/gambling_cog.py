import discord

from discord.ext import commands

import secrets

import time

from .economy_cog import get_user_data, get_data, save_data

class GamblingCog(commands.Cog):

    def __init__(self, bot):

        self.bot = bot

    async def handle_bet(self, message, win_chance: int, loss_percent: int):

        parts = message.content.split()

        if len(parts) < 2:

            await message.channel.send("الرجاء تحديد نوع الرهان: (ربع/نص/كامل).")

            return

        bet_type = parts[1].lower()

        

        user_id = str(message.author.id)

        data = get_data()

        user_data = get_user_data(user_id)

        

        # --- cooldown يدوي ---

        cooldowns = user_data['cooldowns']

        if time.time() - cooldowns.get('gamble', 0) < 10:

            await message.channel.send(f"الرجاء الانتظار {10 - (time.time() - cooldowns.get('gamble', 0)):.1f} ثواني.")

            return

        

        wallet = user_data['wallet']

        bet_options = {"ربع": wallet // 4, "نص": wallet // 2, "كامل": wallet}

        if bet_type not in bet_options:

            await message.channel.send("الخيار غير صالح. استخدم (ربع/نص/كامل).")

            return

        

        bet_amount = bet_options[bet_type]

        if bet_amount <= 0:

            await message.channel.send("ليس لديك مال كافٍ للعب.")

            return

        roll = secrets.randbelow(100) + 1

        if roll <= win_chance:

            winnings = bet_amount

            data[user_id]['wallet'] += winnings

            result_msg = f"🎉 **مبروك!** لقد ربحت `${winnings:,}`."

        else:

            loss = (bet_amount * loss_percent) // 100

            data[user_id]['wallet'] -= loss

            result_msg = f"💔 **للأسف!** لقد خسرت `${loss:,}`."

        

        data[user_id]['cooldowns']['gamble'] = time.time()

        save_data(data)

        await message.channel.send(f"{result_msg}\nرصيدك الحالي: `${data[user_id]['wallet']:,}`")

async def setup(bot):

    await bot.add_cog(GamblingCog(bot))