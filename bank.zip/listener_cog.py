import discord

from discord.ext import commands

class ListenerCog(commands.Cog):

    def __init__(self, bot):

        self.bot = bot

    @commands.Cog.listener()

    async def on_message(self, message):

        if message.author.bot:

            return

        

        # للسماح للأوامر ذات البادئة بالعمل

        if message.content.startswith(self.bot.command_prefix):

            await self.bot.process_commands(message)

            return

        # ---- موجه الأوامر بدون بادئة ----

        content = message.content.lower().strip()

        

        # Gambling Cog

        if content.startswith('نرد '):

            gambling_cog = self.bot.get_cog('GamblingCog')

            await gambling_cog.handle_bet(message, 25, 7)

        elif content.startswith('تداول '):

            gambling_cog = self.bot.get_cog('GamblingCog')

            await gambling_cog.handle_bet(message, 50, 5)

        elif content.startswith('استثمار '):

            gambling_cog = self.bot.get_cog('GamblingCog')

            await gambling_cog.handle_bet(message, 65, 3)

            

        # Assets Cog

        elif content == 'بيوت' or content == 'شراء بيت':

            assets_cog = self.bot.get_cog('AssetsCog')

            await assets_cog.handle_buy_house(message)

        elif content == 'ممتلكات' or content == 'ممتلكاتي':

            assets_cog = self.bot.get_cog('AssetsCog')

            await assets_cog.handle_show_properties(message)

        elif content.startswith('بيع '):

            assets_cog = self.bot.get_cog('AssetsCog')

            await assets_cog.handle_sell(message)

        elif content.startswith('ذهب'):

            assets_cog = self.bot.get_cog('AssetsCog')

            await assets_cog.handle_gold(message)

        elif content == 'صناعة':

            assets_cog = self.bot.get_cog('AssetsCog')

            await assets_cog.handle_craft(message)

        # Jobs Cog

        elif content == 'وظائف' or content == 'وظايف':

            jobs_cog = self.bot.get_cog('JobsCog')

            await jobs_cog.handle_jobs(message)

        elif content == 'شهادات' or content == 'شهايد':

            jobs_cog = self.bot.get_cog('JobsCog')

            await jobs_cog.handle_certificates(message)

            

        # Misc Cog

        elif content == 'بقش' or content == 'بقشيش':

            misc_cog = self.bot.get_cog('MiscCog')

            await misc_cog.handle_tip(message)

        elif content == 'توب' or content == 'اغنياء':

            misc_cog = self.bot.get_cog('MiscCog')

            await misc_cog.handle_top(message)

            

async def setup(bot):

    await bot.add_cog(ListenerCog(bot))