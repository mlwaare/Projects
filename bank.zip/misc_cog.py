import discord

from discord.ext import commands

import random

import time

from .economy_cog import get_user_data, get_data, save_data

class MiscCog(commands.Cog):

    def __init__(self, bot):

        self.bot = bot

    async def handle_tip(self, message):

        ctx = await self.bot.get_context(message)

        user_id = str(ctx.author.id)

        data = get_data()

        cooldowns = get_user_data(user_id)['cooldowns']

        

        if time.time() - cooldowns.get('بقش', 0) < 180:

            remaining = 180 - (time.time() - cooldowns.get('بقش', 0))

            return await ctx.send(f"يمكنك أخذ بقشيش مرة كل 3 دقائق. انتظر {int(remaining)} ثانية.")

            

        amount = random.randint(250, 500)

        data[user_id]['wallet'] += amount

        data[user_id]['cooldowns']['بقش'] = time.time()

        save_data(data)

        await ctx.send(f"💰 لقد حصلت على بقشيش! `${amount:,}`.")

        

    async def handle_top(self, message):

        ctx = await self.bot.get_context(message)

        data = get_data()

        users_data = {uid: udata for uid, udata in data.items() if uid != 'global'}

        if not users_data: return await ctx.send("لا توجد بيانات لعرضها.")

            

        sorted_users = sorted(users_data.items(), 

                              key=lambda item: item[1].get('bank', 0) + item[1].get('wallet', 0), 

                              reverse=True)

        embed = discord.Embed(title="🏆 أغنى 10 أشخاص في السيرفر", color=discord.Color.gold())

        description = ""

        for i, (user_id, user_data) in enumerate(sorted_users[:10], 1):

            try:

                user = await self.bot.fetch_user(int(user_id))

                total = user_data.get('bank', 0) + user_data.get('wallet', 0)

                description += f"{i}. {user.mention} - `${total:,}`\n"

            except (discord.NotFound, ValueError): continue

        

        embed.description = description if description else "لم يتم العثور على مستخدمين."

        await ctx.send(embed=embed)

    @commands.command()

    async def هد(self, ctx):

        user_id = str(ctx.author.id)

        data = get_data()

        cooldowns = get_user_data(user_id)['cooldowns']

        

        if time.time() - cooldowns.get('هد', 0) < 43200:

            return await ctx.send("يمكنك أخذ الهدية مرة كل 12 ساعة.")

            

        amount = random.randint(3000, 5000)

        data[user_id]['wallet'] += amount

        data[user_id]['cooldowns']['هد'] = time.time()

        save_data(data)

        await ctx.send(f"🎁 لقد حصلت على هديتك! `${amount:,}`.")

async def setup(bot):

    await bot.add_cog(MiscCog(bot))