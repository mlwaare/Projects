import discord

from discord.ext import commands

from main import OWNER_IDS # استيراد IDs الملاك من الملف الرئيسي

from .economy_cog import get_user_data, get_data, save_data

# --- دالة التحقق من المالك ---

def is_owner():

    async def predicate(ctx):

        return ctx.author.id in OWNER_IDS

    return commands.check(predicate)

class AdminCog(commands.Cog):

    def __init__(self, bot):

        self.bot = bot

    @commands.command(name='+bal')

    @is_owner()

    async def admin_balance(self, ctx, operator: str, member: discord.Member, amount: int, currency: str):

        if operator not in ['+', '-']: return await ctx.send("استخدم `+` للإضافة أو `-` للخصم.")

        if currency not in ['cash', 'bit']: return await ctx.send("العملة يجب أن تكون `cash` أو `bit`.")

        

        data = get_data()

        user_id = str(member.id)

        get_user_data(user_id) # Ensure user exists

        

        key = 'wallet' if currency == 'cash' else 'bitcoin'

        

        if operator == '+':

            data[user_id][key] += amount

            action = "إضافة"

        else: # operator == '-'

            data[user_id][key] -= amount

            action = "خصم"

        

        save_data(data)

        await ctx.send(f"✅ تم {action} `{amount}` {currency} من/إلى {member.mention}.")

    @commands.command(name='+توظيف')

    @is_owner()

    async def admin_hire_king(self, ctx, member: discord.Member):

        data = get_data()

        user_id = str(member.id)

        user_data = get_user_data(user_id)

        if data['global'].get('king_id'): return await ctx.send("يوجد ملك بالفعل.")

        if user_data.get('job'): return await ctx.send("هذا الشخص موظف بالفعل.")

        # إزالة الشخص من أي وظيفة قديمة (احتياطي)

        old_job = user_data.get('job')

        if old_job and int(user_id) in data['global']['jobs'].get(old_job, []):

            data['global']['jobs'][old_job].remove(int(user_id))

        data[user_id]['job'] = "ملك"

        data['global']['king_id'] = member.id

        save_data(data)

        await ctx.send(f"👑 تم تعيين {member.mention} كـ 'ملك'.")

    @commands.command(name='+ازالة')

    @is_owner()

    async def admin_fire(self, ctx, member: discord.Member):

        data = get_data()

        user_id = str(member.id)

        user_data = get_user_data(user_id)

        current_job = user_data.get('job')

        if not current_job: return await ctx.send("هذا الشخص ليس لديه وظيفة.")

        

        data[user_id]['job'] = None

        if current_job == 'ملك':

            data['global']['king_id'] = None

        elif int(user_id) in data['global']['jobs'].get(current_job, []):

            data['global']['jobs'][current_job].remove(int(user_id))

            

        save_data(data)

        await ctx.send(f"✅ تم إزالة {member.mention} من وظيفته كـ '{current_job}'.")

async def setup(bot):

    await bot.add_cog(AdminCog(bot))