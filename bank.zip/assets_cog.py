import discord

from discord.ext import commands

from discord.ui import Select, View

import time

import random

from .economy_cog import get_user_data, get_data, save_data

HOUSES = {

    "بيت عادي": {"price": 100000}, "بيت متوسط الحجم": {"price": 250000},

    "بيت مع حمام سباحة - دورين": {"price": 650000},

    "بيت كبير 3 أدوار - 2 حمام - 8 غرف": {"price": 1000000}

}

CRYPTO_ASSETS = {"كمبيوتر": {"price": 2}, "بوت": {"price": 5}, "ثغرة": {"price": 10}}

GOLD_PRICE_PER_GRAM = 5000

class AssetsCog(commands.Cog):

    def __init__(self, bot):

        self.bot = bot

    # --- Prefix-less Handlers ---

    async def handle_buy_house(self, message):

        ctx = await self.bot.get_context(message)

        options = [discord.SelectOption(label=name, description=f"السعر: ${details['price']:,}") for name, details in HOUSES.items()]

        select = Select(placeholder="اختر البيت الذي تريد شراءه...", options=options)

        async def callback(interaction: discord.Interaction):

            await interaction.response.defer()

            if interaction.user != ctx.author: return await interaction.followup.send("أنت لست من بدأ هذا الأمر!", ephemeral=True)

            

            house_name = select.values[0]

            house_price = HOUSES[house_name]['price']

            data, user_id = get_data(), str(interaction.user.id)

            user_data = get_user_data(user_id)

            if user_data['wallet'] < house_price: return await interaction.followup.send("رصيدك في المحفظة غير كافٍ.", ephemeral=True)

            

            data[user_id]['wallet'] -= house_price

            data[user_id]['properties'].append(house_name)

            save_data(data)

            await interaction.followup.send(f"🎉 مبروك! لقد اشتريت '{house_name}'.")

        select.callback = callback

        view = View(timeout=60).add_item(select)

        await ctx.send("اختر من قائمة البيوت المتاحة:", view=view)

    async def handle_show_properties(self, message):

        ctx = await self.bot.get_context(message)

        user_data = get_user_data(ctx.author.id)

        props = user_data.get('properties', [])

        if not props: return await ctx.send("أنت لا تملك أي ممتلكات.")

        

        embed = discord.Embed(title=f"ممتلكات {ctx.author.display_name}", color=discord.Color.blue())

        prop_list = "\n".join(f"🏠 {p}" for p in props)

        embed.description = prop_list

        await ctx.send(embed=embed)

    async def handle_sell(self, message):

        ctx = await self.bot.get_context(message)

        parts = message.content.split(maxsplit=1)

        if len(parts) < 2: return await ctx.send("يرجى تحديد اسم الممتلك الذي تريد بيعه. مثال: `بيع بيت عادي`")

        item_name = parts[1].strip()

        

        data, user_id = get_data(), str(ctx.author.id)

        user_data = get_user_data(user_id)

        if item_name not in user_data['properties']: return await ctx.send("أنت لا تملك هذا الممتلك.")

        original_price = HOUSES.get(item_name, {}).get('price')

        if not original_price: return await ctx.send("لا يمكن بيع هذا العنصر.")

        sell_price = original_price // 2

        data[user_id]['properties'].remove(item_name)

        data[user_id]['bank'] += sell_price # البيع يضيف للبنك

        save_data(data)

        await ctx.send(f"✅ تم بيع '{item_name}' مقابل `${sell_price:,}`.")

    async def handle_gold(self, message):

        ctx = await self.bot.get_context(message)

        parts = message.content.split()

        amount = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else None

        

        data = get_data()

        global_data = data['global']

        

        if time.time() - global_data.get('gold_last_restock', 0) > 1800:

            global_data['gold_stock'] = random.randint(10, 30)

            global_data['gold_last_restock'] = time.time()

            save_data(data)

            await ctx.send("✨ تم إعادة تعبئة مخزون الذهب!")

        stock = global_data.get('gold_stock', 0)

        if amount is None:

            return await ctx.send(f"مخزون الذهب: `{stock}` جرام. سعر الجرام: `${GOLD_PRICE_PER_GRAM:,}`.\nللشراء، اكتب `ذهب [الكمية]`")

        

        if amount <= 0: return await ctx.send("يجب شراء جرام واحد على الأقل.")

        if amount > stock: return await ctx.send(f"المخزون غير كافٍ. متاح فقط `{stock}` جرام.")

        

        user_id = str(ctx.author.id)

        user_data = get_user_data(user_id)

        total_cost = amount * GOLD_PRICE_PER_GRAM

        if user_data['wallet'] < total_cost: return await ctx.send(f"رصيدك في المحفظة غير كافٍ. تحتاج إلى `${total_cost:,}`.")

        

        data[user_id]['wallet'] -= total_cost

        data[user_id]['properties'].append(f"{amount} جرام ذهب")

        data['global']['gold_stock'] -= amount

        save_data(data)

        await ctx.send(f"✅ تم شراء `{amount}` جرام ذهب مقابل `${total_cost:,}`.")

    

    # --- Prefixed Commands ---

    @commands.command(aliases=['كو'])

    async def crypto(self, ctx):

        options = [discord.SelectOption(label=name, description=f"السعر: {d['price']} بيتكوين") for name, d in CRYPTO_ASSETS.items()]

        select = Select(placeholder="اختر ما تريد شراءه بالبيتكوين...", options=options)

        async def callback(interaction: discord.Interaction):

            await interaction.response.defer()

            if interaction.user != ctx.author: return await interaction.followup.send("أنت لست من بدأ هذا الأمر!", ephemeral=True)

            asset_name = select.values[0]

            asset_price = CRYPTO_ASSETS[asset_name]['price']

            data, user_id = get_data(), str(interaction.user.id)

            user_data = get_user_data(user_id)

            if user_data['bitcoin'] < asset_price: return await interaction.followup.send(f"تحتاج `{asset_price}` بيتكوين.", ephemeral=True)

            

            data[user_id]['bitcoin'] -= asset_price

            key_map = {"كمبيوتر": "computers", "بوت": "bots", "ثغرة": "exploits"}

            data[user_id]['assets'][key_map[asset_name]] += 1

            save_data(data)

            await interaction.followup.send(f"✅ تم شراء '{asset_name}' بنجاح!")

        view = View(timeout=60).add_item(select)

        await ctx.send("ماذا تريد أن تشتري بالبيتكوين؟", view=view)

    @commands.command()

    async def حال(self, ctx):

        # ... (This command remains prefixed and unchanged) ...

        user_data, assets, now = get_user_data(ctx.author.id), get_user_data(ctx.author.id)['assets'], time.time()

        embed = discord.Embed(title=f"الحالة الرقمية لـ {ctx.author.display_name}", color=0x00ff00)

        embed.add_field(name="💻 كمبيوترات", value=f"`{assets['computers']}`", inline=True)

        embed.add_field(name="🤖 بوتات", value=f"`{assets['bots']}`", inline=True)

        embed.add_field(name="🐛 ثغرات", value=f"`{assets['exploits']}`", inline=True)

        if assets['computers'] > 0:

            remaining = (assets['last_mine_time'] + 300) - now

            status = "✅ جاهز للتعدين" if remaining <= 0 else f"⏳ متبقي {int(remaining // 60)}د {int(remaining % 60)}ث"

            embed.add_field(name="⛏️ التعدين", value=status, inline=False)

        

        if assets['bots'] > 0:

            remaining = (assets['last_bot_build_time'] + 7200) - now

            status = "✅ جاهز للصناعة" if remaining <= 0 else f"⏳ متبقي {int(remaining // 3600)}س {int((remaining % 3600) // 60)}د"

            embed.add_field(name="🏭 صناعة الكمبيوترات", value=status, inline=False)

        await ctx.send(embed=embed)

        

    @commands.command()

    async def تعدين(self, ctx):

        # ... (This command remains prefixed and unchanged) ...

        data, user_id = get_data(), str(ctx.author.id)

        assets = get_user_data(user_id)['assets']

        if assets['computers'] == 0: return await ctx.send("أنت لا تملك أي كمبيوترات.")

        if time.time() - assets['last_mine_time'] < 300: return await ctx.send("الرجاء الانتظار.")

        

        mined = assets['computers']

        data[user_id]['bitcoin'] += mined

        data[user_id]['assets']['last_mine_time'] = time.time()

        save_data(data)

        await ctx.send(f"⛏️ نجح التعدين! حصلت على `{mined}` بيتكوين.")

            

    @commands.command()

    async def ثغرة(self, ctx):

        # ... (This command remains prefixed and unchanged) ...

        data, user_id = get_data(), str(ctx.author.id)

        assets = get_user_data(user_id)['assets']

        if assets['exploits'] == 0: return await ctx.send("يجب أن تشتري 'ثغرة' أولاً.")

        

        earnings = sum(random.randint(5000, 300000) for _ in range(assets['exploits']))

        data[user_id]['wallet'] += earnings

        save_data(data)

        await ctx.send(f"🐛 لقد استغليت ثغرة وحصلت على `${earnings:,}`!")

        

    async def handle_craft(self, message):

        ctx = await self.bot.get_context(message)

        data, user_id = get_data(), str(ctx.author.id)

        assets = get_user_data(user_id)['assets']

        if assets['bots'] == 0: return await ctx.send("أنت لا تملك أي بوتات.")

        if time.time() - assets['last_bot_build_time'] < 7200: return await ctx.send("الرجاء الانتظار.")

        built = assets['bots']

        data[user_id]['assets']['computers'] += built

        data[user_id]['assets']['last_bot_build_time'] = time.time()

        save_data(data)

        await ctx.send(f"🏭 نجحت الصناعة! حصلت على `{built}` كمبيوتر جديد.")

async def setup(bot):

    await bot.add_cog(AssetsCog(bot))